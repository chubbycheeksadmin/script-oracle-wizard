module.exports=[80139,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sanitize-script_route_actions_72133704.js.map