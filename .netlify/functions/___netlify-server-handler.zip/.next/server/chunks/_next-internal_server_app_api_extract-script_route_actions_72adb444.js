module.exports=[86798,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_extract-script_route_actions_72adb444.js.map