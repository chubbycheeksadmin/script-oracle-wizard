module.exports=[19055,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_breakdown-script_route_actions_928ed337.js.map