var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/breakdown-script/route.js")
R.c("server/chunks/[externals]_next_dist_8dbe5856._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_4ae31a54.js")
R.c("server/chunks/node_modules_@anthropic-ai_sdk_index_mjs_b618add1._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_breakdown-script_route_actions_928ed337.js")
R.m(87642)
module.exports=R.m(87642).exports
