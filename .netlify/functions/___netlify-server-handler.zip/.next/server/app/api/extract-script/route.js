var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/extract-script/route.js")
R.c("server/chunks/[root-of-the-server]__81f41512._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_@anthropic-ai_sdk_index_mjs_b618add1._.js")
R.c("server/chunks/_next-internal_server_app_api_extract-script_route_actions_72adb444.js")
R.m(38020)
module.exports=R.m(38020).exports
