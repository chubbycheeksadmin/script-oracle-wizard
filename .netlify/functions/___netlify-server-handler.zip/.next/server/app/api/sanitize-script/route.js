var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sanitize-script/route.js")
R.c("server/chunks/[root-of-the-server]__616b3b64._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_sanitize-script_route_actions_72133704.js")
R.m(24379)
module.exports=R.m(24379).exports
