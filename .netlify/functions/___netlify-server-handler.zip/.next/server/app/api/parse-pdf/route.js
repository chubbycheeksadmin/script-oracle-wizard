var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/parse-pdf/route.js")
R.c("server/chunks/[externals]_next_dist_8dbe5856._.js")
R.c("server/chunks/[root-of-the-server]__a3affc62._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_parse-pdf_route_actions_87d0010f.js")
R.m(78500)
module.exports=R.m(78500).exports
